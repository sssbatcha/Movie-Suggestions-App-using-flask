from flask import Flask,request, render_template,redirect,url_for
from flask_mysqldb import MySQL



app = Flask(__name__)

app.config['MYSQL_HOST']= "localhost"
app.config['MYSQL_DB']= "flask2"
app.config['MYSQL_USER']= "root"
app.config['MYSQL_PASSWORD']= "Mdasiq786@"
app.config['MYSQL_CURSORCLASS']="DictCursor"
app.secret_key="myapp"

conn = MySQL(app)
@app.route('/')
def home():
    return render_template('home page.html')

@app.route('/signin', methods = ['POST', 'GET'])
def signin():
    if request.method  == 'POST':
        email = request.form['email']
        password = request.form['password']
        con=conn.connection.cursor()
        sql = "select Email, Password from signup WHERE Email= %s and  Password=%s"
        result=con.execute(sql,(email,password))
        con.connection.commit()
        con.close()
        
        if result:
             return render_template('movie.html')
    
           
        else:
            return render_template('login.html')
            
        
    return render_template('login.html')

@app.route('/signup', methods = ['POST', 'GET'])
def signup():
    if request.method  == 'POST':
        Name = request.form['name']
        Email=request.form['email']
        Password = request.form['password']
        con=conn.connection.cursor()
        sql = "insert into signup(name,email,password) values  (%s,%s,%s);"
        result=con.execute(sql,(Name,Email,Password))
        con.connection.commit()
        con.close()
        return  redirect(url_for('signin'))
        
    return render_template('sigup.html')

@app.route('/add/', methods = ['POST', 'GET'])
def add():
    if request.method  == 'POST':
        name = request.form['name']
        watsapp_no = request.form['watsapp_no']
        door_no = request.form['door_no']
        street = request.form['street']
        city = request.form['city']
        pincode = request.form['pincode']
        con=conn.connection.cursor()
        sql = "insert into addrbook(name,watsapp_no,door_no,street,city,pincode) values  (%s,%s,%s,%s,%s,%s)"
        result=con.execute(sql,(name,watsapp_no,door_no,street,city,pincode))
        con.connection.commit()
        con.close()
        return  redirect(url_for('addrbook1'))
        
    return render_template('add.html')
        
                                                                                                                                                                        
@app.route('/addrbook1/',methods=['GET', 'POST'])
def addrbook1():
    
    con=conn.connection.cursor()
    sql="select * from  addrbook"
    con.execute(sql)
    result= con.fetchall()
    con.connection.commit()    
    return render_template('addrbook1.html',rows=result)
    
    
@app.route('/add1/',methods=['GET', 'POST'])
def add1(): 
    return render_template('add.html')
        
@app.route('/search/',methods=['GET', 'POST'])
def search():
    return render_template('search.html')
    
    
@app.route('/action',methods=['GET', 'POST'])
def action():    
    
        return render_template('action2.html')
    
@app.route('/crime',methods=['GET', 'POST'])
def crime():    
    
        return render_template('crime.html')
@app.route('/romance',methods=['GET', 'POST'])
def romance():    
    
        return render_template('romantic.html')
    
@app.route('/thriller',methods=['GET', 'POST'])
def thriller():    
    
        return render_template('thriller.html')
@app.route('/scifi',methods=['GET', 'POST'])
def scifi():   
    return render_template('sci-fi.html')
@app.route('/david',methods=['GET', 'POST'])
def david():   
    return render_template('davidfincher.html')
@app.route('/nolan',methods=['GET', 'POST'])
def nolan():   
    return render_template('christnolan.html')
    
@app.route('/martin',methods=['GET', 'POST'])
def martin():   
    return render_template('martin.html')
@app.route('/torantino',methods=['GET', 'POST'])
def torantino():   
    return render_template('torantino.html')
@app.route('/mani',methods=['GET', 'POST'])
def mani():   
    return render_template('maniratnam.html')
    
@app.route('/bale',methods=['GET', 'POST'])
def bale():   
    return render_template('christianbale.html')
@app.route('/leonardo',methods=['GET', 'POST'])
def leonardo():   
    return render_template('leonardo.html')
@app.route('/kamal',methods=['GET', 'POST'])
def kamal():   
    return render_template('kamal.html')
@app.route('/pitt',methods=['GET', 'POST'])
def pitt():   
    return render_template('bradpitt.html')

@app.route('/vikram',methods=['GET', 'POST'])
def vikram():   
    return render_template('vikram.html')
    
@app.route('/aboutus',methods=['GET', 'POST'])
def aboutus():   
    return render_template('aboutus.html')

@app.route('/homepage',methods=['GET', 'POST'])
def homepage():   
    return render_template('home page.html')

@app.route('/contactus',methods=['GET', 'POST'])
def contactus():   
    if request.method  == 'POST':
        Name = request.form['name']
        Email=request.form['email']
        Message = request.form['message']
        con=conn.connection.cursor()
        sql = "insert into contactus(name,email,message) values  (%s,%s,%s);"
        result=con.execute(sql,(Name,Email,Message))
        con.connection.commit()
        con.close()
    return render_template('contactus.html')
    

    
 
if __name__ =='__main__':
    app.run(debug=True) 

 
 
if __name__ =='__main__':
    app.run(debug=True)
    

 
 
if __name__ =='__main__':
    app.run(debug=True)
    

 
 
if __name__ =='__main__':
    app.run(debug=True)

 

 
 
if __name__ =='__main__':
    app.run(debug=True)